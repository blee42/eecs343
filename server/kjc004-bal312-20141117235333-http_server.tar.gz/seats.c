#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>

#include "seats.h"
#include "m_semaphore.h"

#define STANDBY_SIZE 8

// Standby List, represented using a linked list.
// Customers are added to this when their seat is
// unavailable and taken off when a seat is freed.
typedef struct standby_l
{
    int customer_id;
    struct standby_l* next;
} standbyL;

// A few other useful variables have been added here --
// the head of the standby linked list, the length, and
// the semaphore object we use to control the list.
seat_t* seat_header = NULL;
standbyL* head = NULL;
int standby_length = 0;
m_sem_t* semaphore;

char seat_state_to_char(seat_state_t);

void list_seats(char* buf, int bufsize)
{
    seat_t* curr = seat_header;
    int index = 0;
    while(curr != NULL && index < bufsize+ strlen("%d %c,"))
    {
        int length = snprintf(buf+index, bufsize-index, 
                "%d %c,", curr->id, seat_state_to_char(curr->state));
        if (length > 0)
            index = index + length;
        curr = curr->next;
    }
    if (index > 0)
        snprintf(buf+index-1, bufsize-index-1, "\n");
    else
        snprintf(buf, bufsize, "No seats not found\n\n");
}

void view_seat(char* buf, int bufsize,  int seat_id, int customer_id, int customer_priority)
{
    seat_t* curr = seat_header;
    while(curr != NULL)
    {
        if(curr->id == seat_id)
        {
            if(curr->state == AVAILABLE || (curr->state == PENDING && curr->customer_id == customer_id))
            {
                snprintf(buf, bufsize, "Confirm seat: %d %c ?\n\n",
                        curr->id, seat_state_to_char(curr->state));
                curr->state = PENDING;
                curr->customer_id = customer_id;
            }
            else
            {
                snprintf(buf, bufsize, "Seat unavailable\n\n");

                // Thread safe adding of a new standby customer the standby list.
                // We add the customer to the end of the list if there's space.
                if (standby_length != STANDBY_SIZE)
                {
                    sem_wait(semaphore);
                    standbyL* new_standby = (standbyL*) malloc(sizeof(standbyL));
                    new_standby->customer_id = customer_id;
                    new_standby->next = NULL;

                    standbyL* iter = head;

                    if (standby_length == 0)
                    {
                        head = new_standby;
                    }
                    else
                    {
                        while (iter->next != NULL)
                            iter = iter->next;

                        iter->next = new_standby;
                    }

                    standby_length++;
                    sem_post(semaphore);
                }

            }

            return;
        }
        curr = curr->next;
    }
    snprintf(buf, bufsize, "Requested seat not found\n\n");
    return;
}

void confirm_seat(char* buf, int bufsize, int seat_id, int customer_id, int customer_priority)
{
    printf("Confirming seat %d for user %d\n", seat_id, customer_id);
    seat_t* curr = seat_header;
    while(curr != NULL)
    {
        if(curr->id == seat_id)
        {
            pthread_mutex_lock(curr->mutex);
            printf("Seat %d locked\n",seat_id );
            if(curr->state == PENDING && curr->customer_id == customer_id )
            {
                snprintf(buf, bufsize, "Seat confirmed: %d %c\n\n",
                        curr->id, seat_state_to_char(curr->state));
                curr->state = OCCUPIED;
            }
            else if(curr->customer_id != customer_id )
            {
                snprintf(buf, bufsize, "Permission denied - seat held by another user\n\n");
            }
            else if(curr->state != PENDING)
            {
                snprintf(buf, bufsize, "No pending request\n\n");
            }
            pthread_mutex_unlock(curr->mutex);
            printf("Seat %d unlocked\n",seat_id );
            return;
        }
        curr = curr->next;
    }
    snprintf(buf, bufsize, "Requested seat not found\n\n");
    printf("seat not found\n");
    
    return;
}

void cancel(char* buf, int bufsize, int seat_id, int customer_id, int customer_priority)
{
    printf("Cancelling seat %d for user %d\n", seat_id, customer_id);

    seat_t* curr = seat_header;
    while(curr != NULL)
    {
        if(curr->id == seat_id)
        {
            pthread_mutex_lock(curr->mutex);
            printf("Seat %d locked\n",seat_id );
            if(curr->state == PENDING && curr->customer_id == customer_id )
            {
                snprintf(buf, bufsize, "Seat request cancelled: %d %c\n\n",
                        curr->id, seat_state_to_char(curr->state));

                // Thread safe reassignment of a cancelled seat to 
                // a customer that previous was unable to get a seat.
                // The first customer on the standby list is given
                // this cancelled seat.
                if (standby_length > 0)
                {
                    sem_wait(semaphore);
                    curr->customer_id = head->customer_id;
                    head = head->next;
                    curr->state = OCCUPIED;
                    standby_length--;
                    sem_post(semaphore);
                }
                else
                {
                    curr->state = AVAILABLE;
                }
            }
            else if(curr->customer_id != customer_id )
            {
                snprintf(buf, bufsize, "Permission denied - seat held by another user\n\n");
            }
            else if(curr->state != PENDING)
            {
                snprintf(buf, bufsize, "No pending request\n\n");
            }
            pthread_mutex_unlock(curr->mutex);
            printf("Seat %d unlocked\n",seat_id );
            return;
        }
        curr = curr->next;
    }
    snprintf(buf, bufsize, "Seat not found\n\n");
    printf("seat not found\n");
    
    return;
}

// A few more variables have been initialized here, namely a mutex
// for each seat node and the main semaphore.
void load_seats(int number_of_seats)
{
    seat_t* curr = NULL;
    int i;
    for(i = 0; i < number_of_seats; i++)
    {   
        seat_t* temp = (seat_t*) malloc(sizeof(seat_t));
        temp->id = i;
        temp->customer_id = -1;
        temp->state = AVAILABLE;
        temp->next = NULL;

        pthread_mutex_t* mutex = (pthread_mutex_t*) malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(mutex, NULL);
        temp->mutex = mutex;
        
        if (seat_header == NULL)
        {
            seat_header = temp;
        }
        else
        {
            curr-> next = temp;
        }
        curr = temp;
    }

    semaphore = (m_sem_t*) malloc(sizeof(m_sem_t));
    sem_init(semaphore);
}

// Now also destroys mutexs and the main semaphore!
void unload_seats()
{
    seat_t* curr = seat_header;
    while(curr != NULL)
    {
        seat_t* temp = curr;
        curr = curr->next;
        pthread_mutex_destroy(temp->mutex);
        free(temp);
    }

    sem_destroy(semaphore);
    free(semaphore);    
}

char seat_state_to_char(seat_state_t state)
{
    switch(state)
    {
        case AVAILABLE:
            return 'A';
        case PENDING:
            return 'P';
        case OCCUPIED:
            return 'O';
    }

    return '?';
}
